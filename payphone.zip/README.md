# Payphone Test

Uso de Boton de Pagos rápido

## Documentation
- [Knowledge Base](https://nuevodocs.livepayphone.com/expresscheckout/)
- [Express Checkout](https://docs.payphone.app/en/knowledge-base/botondepago/)